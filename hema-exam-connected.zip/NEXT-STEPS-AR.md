# الخطوة التالية بعد تفعيل حساب الأدمن

1. انسخ ملفات المشروع إلى مشروع Next.js.
2. أنشئ `.env.local` اعتمادًا على `.env.example`.
3. نفّذ `npm install` ثم `npm run dev`.
4. افتح `/login` وسجّل الدخول بحساب Supabase Auth الذي يحمل app_metadata.role = admin.
5. افتح `/admin/questions` لرفع JSON، و`/admin/results` لمراجعة النتائج.

تنبيه: تم دمج لوحة الأدمن ورفع JSON والنتائج وإعدادات المدة مع الهيكل السابق. لا تنشر تدفق امتحان الطلاب القديم قبل تحديثه لاستخدام RPC الآمنة في قاعدة البيانات: start_student_exam و get_exam_questions و submit_student_exam.
