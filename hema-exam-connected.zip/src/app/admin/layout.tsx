"use client";
import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/browser";
export default function AdminLayout({children}:{children:React.ReactNode}) {
 const router=useRouter(); const path=usePathname(); const [ready,setReady]=useState(false);
 useEffect(()=>{(async()=>{const {data:{session}}=await supabaseBrowser().auth.getSession();
   if(!session){router.replace("/login");return}
   const {data:{user}}=await supabaseBrowser().auth.getUser();
   if(user?.app_metadata?.role!=="admin"){await supabaseBrowser().auth.signOut();router.replace("/login?error=not_admin");return}
   setReady(true);
 })()},[router]);
 if(!ready)return <div className="panel p-6 mt-8 text-center">جارٍ التحقق من صلاحيات الأدمن...</div>;
 return <div>{children}</div>;
}
