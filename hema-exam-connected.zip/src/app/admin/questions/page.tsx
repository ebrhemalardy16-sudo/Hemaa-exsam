"use client";
import {useState} from "react";import {supabaseBrowser} from "@/lib/supabase/browser";
type Q={type:"mcq"|"true_false"|"essay";question:string;options?:string[]|null;correct?:string|null;model_answer?:string|null;keywords?:string[];explanation?:string|null;points?:number};
type SubjectBlock={name:string;duration_minutes?:number;questions:Q[]};
export default function Questions(){const [file,setFile]=useState<File|null>(null);const [status,setStatus]=useState("");const [busy,setBusy]=useState(false);const [preview,setPreview]=useState<{subjects:number;questions:number}|null>(null);
 async function importFile(){if(!file)return;setBusy(true);setStatus("جارٍ قراءة الملف...");try{
  const parsed=JSON.parse(await file.text());const blocks:SubjectBlock[]=parsed.subjects;
  if(!Array.isArray(blocks)||!blocks.length)throw new Error("صيغة JSON غير صحيحة: يجب وجود subjects كمصفوفة.");
  const db=supabaseBrowser();let inserted=0;
  for(const s of blocks){if(!s.name||!Array.isArray(s.questions))throw new Error("كل مادة يجب أن تحتوي على name و questions.");
   const {data:subject,error:se}=await db.from("subjects").upsert({name:s.name,duration_minutes:s.duration_minutes||30},{onConflict:"name"}).select("id").single();
   if(se||!subject)throw new Error("تعذر حفظ المادة: "+(se?.message||s.name));
   const rows=s.questions.map(q=>{if(!["mcq","true_false","essay"].includes(q.type)||!q.question)throw new Error("يوجد سؤال ناقص أو نوع سؤال غير صحيح.");return {subject_id:subject.id,type:q.type,question:q.question,options:q.options??null,correct:q.correct??null,model_answer:q.model_answer??null,keywords:q.keywords??[],explanation:q.explanation??null,points:q.points??1}});
   for(let i=0;i<rows.length;i+=100){const {error}=await db.from("questions").insert(rows.slice(i,i+100));if(error)throw new Error("فشل إدخال الأسئلة: "+error.message);inserted+=Math.min(100,rows.length-i)}
  }
  setPreview({subjects:blocks.length,questions:inserted});setStatus(`تم استيراد ${inserted} سؤال بنجاح.`);
 }catch(e){setStatus(e instanceof Error?e.message:"حدث خطأ أثناء الاستيراد.");}finally{setBusy(false)}}
 return <div><h1 className="gold text-2xl font-bold mb-3">رفع بنك الأسئلة</h1><div className="panel p-5 grid gap-4"><p className="text-gray-300">ارفع ملف JSON يحتوي على المواد والأسئلة. أنواع الأسئلة: mcq و true_false و essay.</p><input className="field" type="file" accept=".json,application/json" onChange={e=>{setFile(e.target.files?.[0]||null);setPreview(null);setStatus("")}}/><button className="btn" disabled={!file||busy} onClick={()=>void importFile()}>{busy?"جارٍ الاستيراد...":"استيراد الأسئلة إلى Supabase"}</button>{status&&<p className={status.startsWith("تم")?"text-green-400":"text-yellow-300"}>{status}</p>}{preview&&<p className="text-sm text-gray-300">المواد: {preview.subjects} — الأسئلة: {preview.questions}</p>}</div><div className="panel p-5 mt-4"><h2 className="gold font-bold mb-2">مثال لصيغة الملف</h2><pre className="text-xs whitespace-pre-wrap text-gray-300" dir="ltr">{`{
  "subjects": [
    {
      "name": "مدخل القانون",
      "duration_minutes": 30,
      "questions": [
        {
          "type": "mcq",
          "question": "نص السؤال؟",
          "options": ["اختيار أ", "اختيار ب"],
          "correct": "اختيار أ",
          "points": 1
        },
        {
          "type": "true_false",
          "question": "نص العبارة",
          "correct": "صح",
          "points": 1
        },
        {
          "type": "essay",
          "question": "اشرح...",
          "model_answer": "الإجابة النموذجية",
          "keywords": ["مصطلح1", "مصطلح2"],
          "points": 5
        }
      ]
    }
  ]
}`}</pre><p className="text-xs text-yellow-200 mt-3">تنبيه: الاستيراد الحالي يضيف الأسئلة ولا يحذف الأسئلة القديمة. لا ترفع الملف مرتين حتى لا تتكرر الأسئلة.</p></div></div>
}
