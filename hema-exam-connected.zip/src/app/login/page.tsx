"use client";
import {useState} from "react"; import {supabaseBrowser} from "@/lib/supabase/browser"; import {useRouter} from "next/navigation";
export default function Login(){const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [err,setErr]=useState("");const [busy,setBusy]=useState(false);const router=useRouter();
 async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setErr("");const db=supabaseBrowser();const {error}=await db.auth.signInWithPassword({email,password});
 if(error){setErr("بيانات الدخول غير صحيحة.");setBusy(false);return}
 const {data:{user}}=await db.auth.getUser();
 if(user?.app_metadata?.role!=="admin"){await db.auth.signOut();setErr("الحساب غير مصرح له بدخول لوحة الأدمن.");setBusy(false);return}
 router.replace("/admin/dashboard");
 }
 return <div className="panel max-w-md mx-auto p-6 mt-10"><h1 className="gold text-2xl font-bold mb-5">دخول Hema</h1><form onSubmit={submit} className="grid gap-3"><input className="field" type="email" placeholder="البريد الإلكتروني" value={email} onChange={e=>setEmail(e.target.value)} required/><input className="field" type="password" placeholder="كلمة المرور" value={password} onChange={e=>setPassword(e.target.value)} required/><button className="btn" disabled={busy}>{busy?"جارٍ الدخول...":"تسجيل الدخول"}</button>{err&&<p className="text-red-400">{err}</p>}</form></div>
}
