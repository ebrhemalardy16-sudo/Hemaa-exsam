export type QuestionType="mcq"|"true_false"|"essay";
export type Question={id:string;subject_id:string;type:QuestionType;question:string;options:string[]|null;correct:string|null;model_answer:string|null;keywords:string[]|null;explanation:string|null;points:number};
export type Subject={id:string;name:string;duration_minutes:number};