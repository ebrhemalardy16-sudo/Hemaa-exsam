import { createClient } from "@supabase/supabase-js";
import data from "../data.json";
const url=process.env.NEXT_PUBLIC_SUPABASE_URL!;
const key=process.env.SUPABASE_SERVICE_ROLE_KEY!;
if(!url||!key) throw new Error("Set Supabase URL and service role key in .env.local");
const db=createClient(url,key);
async function main(){
 for(const s of data.subjects){
  const {data:subject,error}=await db.from("subjects").upsert({name:s.name,duration_minutes:s.duration_minutes},{onConflict:"name"}).select().single();
  if(error) throw error;
  if(s.questions.length){
   const rows=s.questions.map((q:any)=>({...q,subject_id:subject.id}));
   const result=await db.from("questions").insert(rows);
   if(result.error) throw result.error;
  }
 }
 console.log("Seed completed");
}
main().catch(e=>{console.error(e);process.exit(1)});