import type { Config } from "tailwindcss";
const config: Config = { content:["./src/**/*.{js,ts,jsx,tsx,mdx}"], theme:{extend:{colors:{royal:{gold:"#D4AF37",black:"#0A0A0A"}} ,fontFamily:{sans:["Cairo","Tajawal","Arial","sans-serif"]}}},plugins:[]};
export default config;