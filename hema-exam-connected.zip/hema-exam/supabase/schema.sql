create extension if not exists pgcrypto;
create table if not exists public.users(
 id uuid primary key default gen_random_uuid(), name text not null check(length(name)<=80),
 phone text not null check(length(phone)<=20), created_at timestamptz default now()
);
create table if not exists public.subjects(
 id uuid primary key default gen_random_uuid(), name text unique not null,
 duration_minutes int not null default 30 check(duration_minutes between 1 and 240)
);
create type question_type as enum ('mcq','true_false','essay');
create table if not exists public.questions(
 id uuid primary key default gen_random_uuid(), subject_id uuid not null references subjects(id) on delete cascade,
 type question_type not null, question text not null, options jsonb, correct text,
 model_answer text, keywords text[] default '{}', explanation text, points numeric(7,2) not null default 1
);
create table if not exists public.exams(
 id uuid primary key default gen_random_uuid(), user_id uuid not null references users(id),
 subject_id uuid not null references subjects(id), started_at timestamptz not null default now(),
 submitted_at timestamptz, score numeric(8,2) default 0, total_points numeric(8,2) default 0,
 status text not null default 'in_progress' check(status in ('in_progress','submitted','reviewed'))
);
create table if not exists public.answers(
 id uuid primary key default gen_random_uuid(), exam_id uuid not null references exams(id) on delete cascade,
 question_id uuid not null references questions(id), student_answer text,
 auto_score numeric(8,2) default 0, manual_score numeric(8,2), is_correct boolean
);
create index if not exists exams_subject_idx on exams(subject_id);
create index if not exists exams_user_idx on exams(user_id);
-- Enable RLS. Public client should not be granted broad write access in production.
alter table users enable row level security;
alter table subjects enable row level security;
alter table questions enable row level security;
alter table exams enable row level security;
alter table answers enable row level security;
-- Read-only catalogue policies; all writes should go through protected server routes.
create policy "subjects readable" on subjects for select using (true);
create policy "questions readable" on questions for select using (true);
-- Seed the six subjects
insert into subjects(name,duration_minutes) values
('مدخل القانون',30),('القانون الدستوري',30),('المصطلحات القانونية بالإنجليزية',30),
('الحاسب الآلي',30),('التشريع',30),('تاريخ النظم القانونية',30)
on conflict(name) do nothing;
