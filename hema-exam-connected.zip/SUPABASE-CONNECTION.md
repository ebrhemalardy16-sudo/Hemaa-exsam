# ربط لوحة Hema بمشروع Supabase

## متغيرات البيئة
ضع القيم التالية في `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL=https://gpdijwxhiijwnwqakvxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_C3z6TvUNKbYiZlHa39A3uQ_evuxr-gK
```
هذا المفتاح Publishable ويمكن استخدامه في المتصفح. لا تضع أي `service_role` أو secret key في `NEXT_PUBLIC`.

## تفعيل حساب الأدمن
1. أنشئ المستخدم من Supabase Dashboard > Authentication > Users.
2. نفّذ في SQL Editor (استبدل البريد ببريد الأدمن الحقيقي):
```
update auth.users
set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb
where lower(email) = lower('YOUR_ADMIN_EMAIL');
```
3. سجّل خروجًا ثم دخولًا من `/login` حتى تصدر جلسة جديدة تحتوي على role في app_metadata.

## استخدام الملفات
انسخ الملفات الموجودة في `src/` إلى مشروع Next.js الحالي مع الحفاظ على نفس المسارات. استبدل صفحات الأدمن والـ browser client بالنسخ هنا. شغّل `npm install` إذا احتجت ثم `npm run dev`.

## صيغة بنك الأسئلة
الجذر `subjects`; كل مادة تحتوي `name`, `duration_minutes`, `questions`. أنواع الأسئلة `mcq`, `true_false`, `essay`. في mcq اكتب `options` و`correct` بنفس نص أحد الخيارات. في true_false اجعل `correct` إما `صح` أو `خطأ`. في essay أضف `model_answer` و`keywords`.

## تنبيه أمني وتشغيلي
- صفحات الأدمن هذه تعتمد على تسجيل دخول Supabase Auth وRLS مع claim موثوق `app_metadata.role=admin`.
- لا تمنح anon صلاحية select على `users`, `exams`, `answers`, أو `questions` مباشرة.
- الاستيراد يضيف الأسئلة ولا يحذف القديم؛ رفع الملف نفسه مرتين يكرر الأسئلة.
- صفحات الامتحان في النسخة الأولية تحتاج أيضًا تحديثًا لاستخدام RPCs الآمنة `start_student_exam`, `get_exam_questions`, `submit_student_exam` بدل الكتابة المباشرة إلى الجداول. لا تنشر تدفق امتحان الطلاب القديم قبل هذا التعديل.
- بيانات النتائج مرئية للأدمن فقط حسب سياسات RLS. لا يمكن للطلاب الوصول إليها مباشرة.
